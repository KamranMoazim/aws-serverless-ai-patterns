#!/usr/bin/env bash
# Build the MicroVM image from ./sandbox and wire its ARN into the orchestrator.
# Usage: BUNDLE_BUCKET=<bucket> ORCH_FN=<fn-name> ./scripts/build_image.sh
set -euo pipefail

REGION="${AWS_REGION:-us-east-1}"
BUNDLE_BUCKET="${BUNDLE_BUCKET:?set BUNDLE_BUCKET (from stack output)}"
ORCH_FN="${ORCH_FN:?set ORCH_FN (orchestrator function name)}"
IMAGE_NAME="${IMAGE_NAME:-code-sandbox}"
KEY="microvm/sandbox-$(date +%s).zip"

# 1. Zip the sandbox (Dockerfile + app) and upload to S3
( cd sandbox && zip -qr /tmp/sandbox.zip . )
aws s3 cp /tmp/sandbox.zip "s3://${BUNDLE_BUCKET}/${KEY}" --region "$REGION"

# 2. Find the Lambda-published managed base image ARN for MicroVMs.
#    VERIFY this against the "Create your first MicroVM" tutorial / list API — the
#    exact base ARN and parameter names may differ.
BASE_IMAGE_ARN="${BASE_IMAGE_ARN:?set BASE_IMAGE_ARN to the Lambda managed MicroVM base image ARN}"

# 3. Create the image (async build → snapshot). Confirm the CLI shape for your region.
IMAGE_ARN=$(aws lambda-microvms create-microvm-image \
  --image-name "$IMAGE_NAME" \
  --base-image-arn "$BASE_IMAGE_ARN" \
  --code "{\"s3Bucket\":\"${BUNDLE_BUCKET}\",\"s3Key\":\"${KEY}\"}" \
  --region "$REGION" \
  --query 'imageArn' --output text)
echo "Image build started: $IMAGE_ARN"

# 4. Wait for the build to reach SUCCESSFUL (2–3 min).
echo "Waiting for image build (2-3 min)…"
while :; do
  STATUS=$(aws lambda-microvms get-microvm-image --image-identifier "$IMAGE_ARN" \
    --region "$REGION" --query 'status' --output text 2>/dev/null || echo PENDING)
  echo "  status: $STATUS"
  [ "$STATUS" = "SUCCESSFUL" ] && break
  [ "$STATUS" = "FAILED" ] && { echo "image build FAILED"; exit 1; }
  sleep 15
done

# 5. Point the orchestrator at the new image.
aws lambda update-function-configuration \
  --function-name "$ORCH_FN" \
  --environment "Variables={SESSIONS_TABLE=$(aws lambda get-function-configuration --function-name "$ORCH_FN" --region "$REGION" --query 'Environment.Variables.SESSIONS_TABLE' --output text),MODEL_ID=us.anthropic.claude-haiku-4-5-20251001-v1:0,MICROVM_IMAGE_ARN=$IMAGE_ARN}" \
  --region "$REGION" >/dev/null
echo "Done. Orchestrator now uses $IMAGE_ARN"
