# NOTES — AI code sandbox on Lambda MicroVMs (project #5)

Private build notes. Delete before mirroring to public repo.

## Verified (from AWS docs, July 2026)
- boto3 client "lambda-microvms". run_microvm(imageIdentifier, idlePolicy) -> {microvmId, endpoint}.
  create_microvm_auth_token(microvmIdentifier, expirationInMinutes, allowedPorts=[{"allPorts":{}}])
  -> authToken["X-aws-proxy-auth"]. Connect: HTTPS to endpoint with X-aws-proxy-auth header.
- Lifecycle: PENDING→RUNNING (run + /run hook), RUNNING→SUSPENDING/SUSPENDED (idle or suspend API),
  SUSPENDED→RUNNING (autoResume on traffic), →TERMINATING (terminate or max duration).
- Image: zip(Dockerfile+app)→S3, create image on a Lambda-published managed base (base-image-arn).
  Build runs Dockerfile, starts app, waits for /ready 200, snapshots. Versioned. ~2-3 min.
- Hooks the in-VM app should expose: /ready (build), /run (post-restore), /suspend, /terminate.
- Constraints: ARM64, AL2023, 16 vCPU / 32 GB / 8h max, region availability (no São Paulo yet).
- Perf (community): run→RUNNING ~2s (+2s to serve), suspend/resume ~1s each.

## MUST verify on real deploy (couldn't test microvm APIs here)
- create-microvm-image exact CLI/SDK signature + the managed BASE_IMAGE_ARN value.
- Dockerfile FROM: whether it must reference the managed base or Lambda injects it.
- IAM action prefix: lambda:RunMicrovm vs lambda-microvms:RunMicrovm (used lambda: — VERIFY).
- MicroVM execution role trust principal (used lambda.amazonaws.com as placeholder — VERIFY;
  docs mention sts:TagSession in the trust policy, and GetWebIdentityToken).
- Lambda runtime boto3 has the lambda-microvms client; else add a boto3 layer.
- run_microvm may need runtime network connectors / execution role params beyond imageIdentifier.

## Validated locally
- CDK stack synths to valid CFN (S3 + DynamoDB + Lambda + API GW + IAM w/ RunMicrovm+Bedrock+PassRole).
- orchestrator.py, sandbox/server.py py-compile.

## TODO before publish
- [ ] cdk deploy; build image (get real base ARN); wire ARN; end-to-end curl.
- [ ] Prove isolation (os.uname → aarch64 AL2023) + persistent /workspace across suspend/resume.
- [ ] Fix any IAM prefix / exec-role principal issues; note them (great gotcha content).
- [ ] Screenshot the two-request isolation+state demo.
- [ ] Diagram ../diagrams/microvm-sandbox.png; cost number.
