# AI Code Sandbox — Bedrock Writes It, a Lambda MicroVM Runs It (CDK)

```
User → API Gateway → Orchestrator Lambda
                       ├→ Bedrock (writes Python from the prompt)
                       └→ run-microvm → MicroVM sandbox (executes code, isolated)
                          idlePolicy auto-suspends when idle, resumes on the next request
```

The model writes code; instead of `exec()`-ing it in your own process, each session gets
its own Firecracker **MicroVM** (VM-level isolation, Amazon Linux 2023, per-session state).

## Shape: hybrid IaC

Lambda MicroVMs are brand new — there's no CloudFormation resource for the MicroVM
lifecycle yet, and that's fine: a MicroVM is a *runtime* resource, not deploy-time infra.
So **CDK owns the durable pieces** (orchestrator Lambda, API Gateway, DynamoDB session map,
S3 image-bundle bucket, IAM) and the **orchestrator drives the lifecycle** (`run_microvm`,
`create_microvm_auth_token`, `terminate`) per request. The **image** is built by a script.

## Layout

```
microvm-code-sandbox/
├── microvm_code_sandbox/…_stack.py   # Lambda + API GW + DynamoDB + S3 + IAM
├── lambdas/orchestrator/orchestrator.py  # Bedrock → run-microvm → POST /execute
├── sandbox/                          # the app baked into the MicroVM image
│   ├── server.py                     # /ready /run /suspend /terminate /health /execute
│   ├── requirements.txt
│   └── Dockerfile
└── scripts/build_image.sh            # zip → S3 → create-microvm-image → wire ARN into Lambda
```

## Deploy (two phases)

```bash
python -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt
cdk bootstrap
cdk deploy                      # phase 1 — durable infra
```

Outputs: `RunUrl`, `BundleBucketName`, `OrchestratorFunction`, `MicrovmExecutionRoleArn`.

```bash
# phase 2 — build the MicroVM image and point the orchestrator at it
BASE_IMAGE_ARN=<lambda managed microvm base image arn> \
BUNDLE_BUCKET=<BundleBucketName> \
ORCH_FN=<OrchestratorFunction> \
./scripts/build_image.sh
```

(Enable Bedrock model access for `MODEL_ID` first.)

## Test

```bash
curl -s -X POST "<RunUrl>" -H 'Content-Type: application/json' \
  -d '{"prompt":"compute the first 15 Fibonacci numbers"}' | jq

# prove VM isolation + persistent state (reuse the returned session_id):
curl -s -X POST "<RunUrl>" -H 'Content-Type: application/json' \
  -d '{"prompt":"print os.uname() and the contents of /etc/os-release","session_id":"<id>"}' | jq
curl -s -X POST "<RunUrl>" -H 'Content-Type: application/json' \
  -d '{"prompt":"write the current time to /workspace/state.txt","session_id":"<id>"}' | jq
# wait past the idle window, then:
curl -s -X POST "<RunUrl>" -H 'Content-Type: application/json' \
  -d '{"prompt":"read and print /workspace/state.txt","session_id":"<id>"}' | jq
```

You should see `Linux aarch64 … Amazon Linux 2023` (not your machine), and the file
surviving a suspend/resume cycle.

## Gotchas / verify-on-deploy (brand-new service)

- **boto3 recency**: the Lambda runtime's boto3 must expose the `lambda-microvms` client;
  if not, attach a recent boto3 layer to the orchestrator.
- **Exact image API**: confirm the `create-microvm-image` CLI/param names and the
  **managed base image ARN** against the "Create your first MicroVM" tutorial in your region.
- **IAM action prefix**: verify `lambda:RunMicrovm` vs a `lambda-microvms:` prefix; the deploy
  succeeds either way, but a wrong prefix → AccessDenied at call time.
- **MicroVM execution-role principal**: the trust principal in the stack is a placeholder —
  set it to the service principal the tutorial specifies.
- **Snapshot uniqueness**: anything unique generated at *build* time is shared across all VMs
  from that image; create per-session state in the `/run` hook (server.py has it).
- **Constraints**: ARM64, AL2023, ~2–3 min image build, run→running ~2–4s, suspend/resume ~1s;
  check region availability.

## Teardown

```bash
cdk destroy
# terminate any running MicroVMs and delete the image via the lambda-microvms API/CLI.
```
