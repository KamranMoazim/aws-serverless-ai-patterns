#!/usr/bin/env python3
import os
import aws_cdk as cdk
from microvm_code_sandbox.microvm_code_sandbox_stack import MicrovmCodeSandboxStack

app = cdk.App()
MicrovmCodeSandboxStack(
    app, "MicrovmCodeSandboxStack",
    env=cdk.Environment(
        account=os.environ["CDK_DEFAULT_ACCOUNT"],
        region=os.environ.get("CDK_DEFAULT_REGION") or "us-east-1",
    ),
)
app.synth()
